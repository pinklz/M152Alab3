# CS M152A Lab 3
Stopwatch lab w/ pause, adjust, + reset buttons